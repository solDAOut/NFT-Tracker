# NFT tracker

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Start

```
npm i

npm start
```

Mobile app - [Android](https://play.google.com/store/apps/details?id=app.nft_tracker_test.twa)
