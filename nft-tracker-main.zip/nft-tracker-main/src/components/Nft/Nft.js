import React from 'react';

function Nft({ nft }) {
  return <div></div>;
}

export default Nft;
